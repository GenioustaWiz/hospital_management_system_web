// Wait for the entire website to load
window.addEventListener('load', function () {
    // Hide the loading animation by removing the loading container element
    var loadingContainer = document.getElementById('preloader');
    loadingContainer.style.display = 'none';
});
